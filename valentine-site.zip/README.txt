# Valentine Website (1-file)

## What you upload
- `index.html` (this is the whole website)

## GitHub Pages (fast)
1) Open your repo on GitHub
2) Click **Add file** → **Upload files**
3) Upload `index.html`
4) Click **Commit changes**
5) Go to **Settings** → **Pages**
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
   - Save
6) Your link will look like:
   https://YOURNAME.github.io/YOURREPO/

## Before you send it to her
1) Open your link
2) Click Yes
3) Write your message
4) Paste the YouTube link
5) Click “Make it ready to send 🔒”
6) Copy the URL again and send that final URL
